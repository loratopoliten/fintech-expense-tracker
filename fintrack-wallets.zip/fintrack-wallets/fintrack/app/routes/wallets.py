"""Wallet routes — multi-account manager with per-account balance tracking."""

from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from datetime import date
from app.database import db_cursor
from app.utils.auth import get_current_user

router = APIRouter()
templates = Jinja2Templates(directory="templates")

WALLET_TYPES = [
    ("bank",   "Bank account"),
    ("mobile", "Mobile money"),
    ("cash",   "Cash"),
    ("savings","Savings account"),
    ("credit", "Credit card"),
    ("investment", "Investment"),
]

PALETTE = [
    "#f0a500", "#1fd87a", "#4f8ef0", "#f04f4f",
    "#a855f7", "#06b6d4", "#f97316", "#ec4899",
    "#84cc16", "#64748b",
]


def _compute_balance(wallet: dict, transactions: list[dict]) -> float:
    """Balance = initial_bal + income - expenses for this wallet."""
    balance = wallet["initial_bal"]
    for t in transactions:
        if t.get("wallet_id") == wallet["id"]:
            if t["type"] == "income":
                balance += t["amount"]
            else:
                balance -= t["amount"]
    return round(balance, 2)


def _get_wallets_with_balances(uid: int) -> list[dict]:
    with db_cursor() as cur:
        cur.execute("SELECT * FROM wallets WHERE user_id=? ORDER BY created_at ASC", (uid,))
        wallets = [dict(r) for r in cur.fetchall()]
        cur.execute("SELECT * FROM transactions WHERE user_id=?", (uid,))
        txns = [dict(r) for r in cur.fetchall()]

    for w in wallets:
        w["balance"] = _compute_balance(w, txns)
        w_txns = [t for t in txns if t.get("wallet_id") == w["id"]]
        w["txn_count"] = len(w_txns)
        w["recent"] = sorted(w_txns, key=lambda t: str(t["date"]), reverse=True)[:5]

    return wallets, txns


# ── List page ────────────────────────────────────────────────

@router.get("", response_class=HTMLResponse)
async def wallets_page(request: Request, user=Depends(get_current_user)):
    uid = user["sub"]
    wallets, all_txns = _get_wallets_with_balances(uid)

    total_balance = round(sum(w["balance"] for w in wallets), 2)

    # Transactions with no wallet assigned (untagged)
    untagged = [t for t in all_txns if t.get("wallet_id") is None]

    # Per-wallet monthly in/out for sparkline data
    current_month = str(date.today())[:7]
    for w in wallets:
        w_txns = [t for t in all_txns if t.get("wallet_id") == w["id"]]
        w["month_in"]  = round(sum(t["amount"] for t in w_txns if t["type"] == "income"  and str(t["date"]).startswith(current_month)), 2)
        w["month_out"] = round(sum(t["amount"] for t in w_txns if t["type"] == "expense" and str(t["date"]).startswith(current_month)), 2)

    return templates.TemplateResponse("wallets/index.html", {
        "request":       request,
        "user":          user,
        "wallets":       wallets,
        "total_balance": total_balance,
        "untagged_count": len(untagged),
        "wallet_types":  WALLET_TYPES,
        "palette":       PALETTE,
        "current_month": current_month,
    })


# ── Create wallet ─────────────────────────────────────────────

@router.post("/create")
async def create_wallet(
    user=Depends(get_current_user),
    name:        str   = Form(...),
    wallet_type: str   = Form("bank"),
    color:       str   = Form("#f0a500"),
    initial_bal: float = Form(0.0),
):
    name = name.strip()
    if not name:
        raise HTTPException(400, "Wallet name required")
    if initial_bal < 0:
        raise HTTPException(400, "Initial balance cannot be negative")

    with db_cursor() as cur:
        try:
            cur.execute(
                "INSERT INTO wallets (user_id, name, type, color, initial_bal) VALUES (?,?,?,?,?)",
                (user["sub"], name, wallet_type, color, initial_bal)
            )
        except Exception:
            raise HTTPException(400, "A wallet with that name already exists")

    return RedirectResponse("/wallets", status_code=303)


# ── Edit wallet ───────────────────────────────────────────────

@router.post("/edit/{wallet_id}")
async def edit_wallet(
    wallet_id:   int,
    user=Depends(get_current_user),
    name:        str   = Form(...),
    wallet_type: str   = Form("bank"),
    color:       str   = Form("#f0a500"),
    initial_bal: float = Form(0.0),
):
    with db_cursor() as cur:
        cur.execute(
            "SELECT id FROM wallets WHERE id=? AND user_id=?", (wallet_id, user["sub"])
        )
        if not cur.fetchone():
            raise HTTPException(404, "Wallet not found")
        cur.execute(
            "UPDATE wallets SET name=?, type=?, color=?, initial_bal=? WHERE id=? AND user_id=?",
            (name.strip(), wallet_type, color, initial_bal, wallet_id, user["sub"])
        )
    return RedirectResponse("/wallets", status_code=303)


# ── Delete wallet ─────────────────────────────────────────────

@router.post("/delete/{wallet_id}")
async def delete_wallet(wallet_id: int, user=Depends(get_current_user)):
    with db_cursor() as cur:
        cur.execute("SELECT id FROM wallets WHERE id=? AND user_id=?", (wallet_id, user["sub"]))
        if not cur.fetchone():
            raise HTTPException(404, "Wallet not found")
        # Unlink transactions instead of deleting them
        cur.execute(
            "UPDATE transactions SET wallet_id=NULL WHERE wallet_id=? AND user_id=?",
            (wallet_id, user["sub"])
        )
        cur.execute("DELETE FROM wallets WHERE id=? AND user_id=?", (wallet_id, user["sub"]))
    return RedirectResponse("/wallets", status_code=303)


# ── Transfer between wallets ──────────────────────────────────

@router.post("/transfer")
async def transfer(
    user=Depends(get_current_user),
    from_wallet: int   = Form(...),
    to_wallet:   int   = Form(...),
    amount:      float = Form(...),
    description: str   = Form("Transfer"),
    date_val:    str   = Form(str(date.today())),
):
    uid = user["sub"]
    if from_wallet == to_wallet:
        raise HTTPException(400, "Cannot transfer to the same wallet")
    if amount <= 0:
        raise HTTPException(400, "Amount must be positive")

    with db_cursor() as cur:
        # Verify both wallets belong to user
        cur.execute("SELECT id FROM wallets WHERE id IN (?,?) AND user_id=?", (from_wallet, to_wallet, uid))
        found = cur.fetchall()
        if len(found) < 2:
            raise HTTPException(404, "Wallet not found")

        note = description.strip() or "Transfer"
        # Debit from source
        cur.execute(
            "INSERT INTO transactions (user_id, type, amount, category, description, date, wallet_id) VALUES (?,?,?,?,?,?,?)",
            (uid, "expense", amount, "Transfer", f"→ {note}", date_val, from_wallet)
        )
        # Credit to destination
        cur.execute(
            "INSERT INTO transactions (user_id, type, amount, category, description, date, wallet_id) VALUES (?,?,?,?,?,?,?)",
            (uid, "income", amount, "Transfer", f"← {note}", date_val, to_wallet)
        )
    return RedirectResponse("/wallets", status_code=303)


# ── Assign untagged transactions to a wallet ──────────────────

@router.post("/assign")
async def assign_transaction(
    user=Depends(get_current_user),
    txn_id:    int = Form(...),
    wallet_id: int = Form(...),
):
    with db_cursor() as cur:
        cur.execute(
            "UPDATE transactions SET wallet_id=? WHERE id=? AND user_id=?",
            (wallet_id, txn_id, user["sub"])
        )
    return RedirectResponse("/wallets", status_code=303)


# ── JSON API for dashboard widget ────────────────────────────

@router.get("/api/summary")
async def wallets_api(user=Depends(get_current_user)):
    wallets, _ = _get_wallets_with_balances(user["sub"])
    return JSONResponse([{
        "id":      w["id"],
        "name":    w["name"],
        "type":    w["type"],
        "color":   w["color"],
        "balance": w["balance"],
        "txn_count": w["txn_count"],
    } for w in wallets])
